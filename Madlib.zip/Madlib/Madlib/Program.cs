﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Robbie Fast
//U2 Madlib
//Nov 7, 2022

namespace Madlib
{
    class Program
    {
        static void Main(string[] args)
        {
            string Creature;
            string Luminous;
            string Ghastly;
            string Spectral;
            string Countryman;
            string Farrier;
            string Farmer;
            string Dreadful;
            string Apparition;
            string Hound;
            string Story;

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine(" ███╗   ███╗ █████╗ ██████╗     ██╗     ██╗██████╗ ██╗ \n ████╗ ████║██╔══██╗██╔══██╗    ██║     ██║██╔══██╗██║ \n ██╔████╔██║███████║██║  ██║    ██║     ██║██████╔╝██║ \n ██║╚██╔╝██║██╔══██║██║  ██║    ██║     ██║██╔══██╗╚═╝ \n ██║ ╚═╝ ██║██║  ██║██████╔╝    ███████╗██║██████╔╝██╗ \n ╚═╝     ╚═╝╚═╝  ╚═╝╚═════╝     ╚══════╝╚═╝╚═════╝ ╚═╝");

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Please enter a noun: ");
            Console.Write(" > ");
            Creature = Console.ReadLine();

            Console.WriteLine("Please enter an adjective: ");
            Console.Write(" > ");
            Luminous = Console.ReadLine();

            Console.WriteLine("Please enter an adjective: ");
            Console.Write(" > ");
            Ghastly = Console.ReadLine();

            Console.WriteLine("Please enter an adjective: ");
            Console.Write(" > ");
            Spectral = Console.ReadLine();

            Console.WriteLine("Please enter a noun: ");
            Console.Write(" > ");
            Countryman = Console.ReadLine();

            Console.WriteLine("Please enter a noun: ");
            Console.Write(" > ");
            Farrier = Console.ReadLine();

            Console.WriteLine("Please enter a noun: ");
            Console.Write(" > ");
            Farmer = Console.ReadLine();

            Console.WriteLine("Please enter an adjective: ");
            Console.Write(" > ");
            Dreadful = Console.ReadLine();

            Console.WriteLine("Please enter a noun: ");
            Console.Write(" > ");
            Apparition = Console.ReadLine();

            Console.WriteLine("Please enter a noun: ");
            Console.Write(" > ");
            Hound = Console.ReadLine();

            Console.WriteLine("Please enter a noun: ");
            Console.Write(" > ");
            Story = Console.ReadLine();

            Story = "They all agreed that it was a huge " + Creature + ", " + Luminous + ", " + Ghastly + ", and " + Spectral + ". I have cross-examined these men, \none of them a hard-headed " + Countryman + ", one a " + Farrier + ", and one a moorland " + Farmer + ", who all tell the same story of this " + Dreadful + " " + Apparition + ", \nexactly corresponding to the " + Hound + " of the legend.";
            Console.WriteLine(Story);

            Console.ReadKey();

        }
    }
}
